<?php
include("db.php");
if (isset($_GET['id'])) {
	$id=$_GET['id'];
	$que="DELETE FROM contact WHERE id='$id'";
	$run=mysqli_query($con, $que);
	if ($run) {
		?>
		<script>
			alert("The message was deleted!");
			window.open("index.php","_self");
		</script>
		<?php
	}
}
?>