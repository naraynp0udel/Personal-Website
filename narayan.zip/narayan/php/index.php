<?php
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome User</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
<style>
	.table {
    width: 100%;
    max-width: 100%;
    margin-bottom: 1rem;
    background-color: transparent;
}


</style>
</head>
<body>
<div class="form">
<h1 >Welcome <?php echo $_SESSION['username']; ?>!</h1>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand">Dashboard</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>
      
      
    </ul>
  </div>
  </nav>
  <div class="container" >
  	<div class="card-body">
	 
		
		<table  class="table table-bordered">
            <thead class="thead-dark">			
		        <tr>
		          <th>ID</th>
		          <th>Name</th>
		          <th>Number</th>
		          <th>Email</th>
		          <th>Massage</th>
		          <th>Manage</th>
		        </tr>
		     </thead>
		     <tbody>
		        
			<?php
			include('db.php');
			$query = 'SELECT * FROM contact';
			$run = mysqli_query($con, $query);
			$counter = 1;
			while($row = mysqli_fetch_array($run)){
			  $id = $row[0];
			  $name = $row[1];
			  $number = $row[2];  
			  $email = $row[3];
			  $msg = $row[4];

			?>
		        <tr>
		          <td><?php echo $id; ?></td>
		          <td><?php echo $name; ?></td>
		          <td><?php echo $number; ?></td>
		          <td><?php echo $email; ?></td>
		          <td><?php echo $msg; ?></td>
		          <td><a href="delete.php?id=<?php echo $id; ?>" class="btn btn-danger">Delete</a></td>
		        </tr>
            </tbody>
		<?php

		$counter++;
		}

		?>
	</table>
    </div>		

</div>
</body>
</html>